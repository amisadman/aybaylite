package com.amisadman.aybay;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

public class BorderItemDecoration extends RecyclerView.ItemDecoration {
    private final Paint paint;
    private final int borderWidth;

    public BorderItemDecoration(int borderWidth, int borderColor) {
        this.borderWidth = borderWidth;
        this.paint = new Paint();
        this.paint.setColor(borderColor);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(borderWidth);
    }

    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        super.onDrawOver(c, parent, state);

        int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = parent.getChildAt(i);
            Rect rect = new Rect();
            rect.left = child.getLeft();
            rect.top = child.getTop();
            rect.right = child.getRight();
            rect.bottom = child.getBottom();
            c.drawRect(rect, paint);
        }
    }
}

