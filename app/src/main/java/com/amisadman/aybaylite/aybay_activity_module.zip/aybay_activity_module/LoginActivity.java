package com.amisadman.aybay;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class LoginActivity extends AppCompatActivity {

    EditText login_password;
    Button login_button;
    TextView signupRedirectText,welcomeText;

    LinearLayout signupLayout;
    DatabaseHelper databaseHelper;

        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_login);
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login_activity), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });

            login_password = findViewById(R.id.login_password);
            login_button = findViewById(R.id.login_button);
            welcomeText = findViewById(R.id.welcomeText);
            signupRedirectText =  findViewById(R.id.signupRedirectText);
            signupLayout = findViewById(R.id.signup_layout);

            databaseHelper = new DatabaseHelper(this);

            String storedName = databaseHelper.getStoredName();
            if (storedName != null) {
                welcomeText.setText("Hello, " + storedName + "!");
                signupLayout.setVisibility(View.GONE);

            } else {
                welcomeText.setText("No user found! Please register.");
            }

            login_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String password = login_password.getText().toString();

                    if (password.isEmpty()) {
                        Toast.makeText(LoginActivity.this, "Please enter PIN!", Toast.LENGTH_SHORT).show();
                    } else {
                        boolean valid = databaseHelper.checkPassword(password);
                        if (valid) {
                            Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                            // Navigate to main app screen
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            intent.putExtra("USERNAME", storedName); // Name pass kore
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(LoginActivity.this, "Incorrect PIN!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
            signupRedirectText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                    startActivity(intent);
                    finish();

                }
            });
        }

    }
