package com.amisadman.aybay;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowData extends AppCompatActivity {

    static RecyclerView recyclerView;
    TextView tvTitle;
    static TextView tvNoDataMessage,tvBalance,tvTotal_show;
    TextView tvtime;
    Button btnAddOther;
    static LottieAnimationView noDataAnimation;

    public static DatabaseHelper dbHelper;

    static ArrayList<HashMap<String, String>> arrayList;
    static HashMap<String, String> hashMap;

    public static boolean EXPENSE = false;
    public static boolean INCOME = false;
    public static boolean LOAN = false;
    public static boolean OWE = false;
    public static boolean SAVINGS = false;
    public static boolean BUDGET = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_show_data);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.showdata_activity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        tvTitle = findViewById(R.id.tvTitle);
        noDataAnimation = findViewById(R.id.noDataAnimation);
        tvNoDataMessage = findViewById(R.id.tvNoDataMessage);
        btnAddOther =findViewById(R.id.btnAddOther);
        tvBalance =findViewById(R.id.tvBalance);
        tvTotal_show =findViewById(R.id.tvTotal_show);
        dbHelper = new DatabaseHelper(this);

        EXPENSE = INCOME = LOAN = OWE = SAVINGS = BUDGET= false;
        Intent intent = getIntent();
        String type = intent.getStringExtra("TYPE");
        if ("EXPENSE".equals(type)) {
            EXPENSE = true;
        } else if ("INCOME".equals(type)) {
            INCOME = true;
        }else if ("LOAN".equals(type)) {
            LOAN = true;
        } else if ("OWE".equals(type)) {
            OWE = true;
        } else if ("SAVINGS".equals(type)) {
            SAVINGS = true;
        } else if ("BUDGET".equals(type)) {
            BUDGET = true;
        }

        if(EXPENSE == true) tvTitle.setText("Expense Statement");
        else if(INCOME == true) tvTitle.setText("Income Statement");
        else if(LOAN == true) {
            tvTitle.setText("Load Statement");
            btnAddOther.setVisibility(View.VISIBLE);
            tvTotal_show.setVisibility(View.VISIBLE);
            tvBalance.setVisibility(View.VISIBLE);
        }
        else if(OWE == true) {
            tvTitle.setText("Owe Statement");
            btnAddOther.setVisibility(View.VISIBLE);
            tvTotal_show.setVisibility(View.VISIBLE);
            tvBalance.setVisibility(View.VISIBLE);
        }
        else if(SAVINGS == true) {
            tvTitle.setText("Savings Statement");
            btnAddOther.setVisibility(View.VISIBLE);
            tvTotal_show.setVisibility(View.VISIBLE);
            tvBalance.setVisibility(View.VISIBLE);
        }
        else if(BUDGET == true) {
            tvTitle.setText("Budget Statement");
            btnAddOther.setVisibility(View.VISIBLE);
            tvTotal_show.setVisibility(View.VISIBLE);
            tvBalance.setVisibility(View.VISIBLE);
        }
        btnAddOther.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowData.this, AddData.class);
                if (LOAN) intent.putExtra("TYPE", "LOAN");
                else if (OWE) intent.putExtra("TYPE", "OWE");
                else if (SAVINGS) intent.putExtra("TYPE", "SAVINGS");
                else if (BUDGET) intent.putExtra("TYPE", "BUDGET");
                startActivity(intent);
            }
        });

        loadData();

        // Add border to each item
        int borderWidth = 2;  // 2px border width
        int borderColor = Color.parseColor("#D3D3D3");  // Light Gray border color
        recyclerView.addItemDecoration(new BorderItemDecoration(borderWidth, borderColor));
    }

    public static void loadData() {
        Cursor cursor = null;
        if(EXPENSE == true) cursor = dbHelper.getAllExpenses();
        else if(INCOME == true) cursor = dbHelper.getAllIncome();
        else if(LOAN == true) cursor = dbHelper.getAllLoans();
        else if(OWE == true) cursor = dbHelper.getAllOwe();
        else if(SAVINGS == true) cursor = dbHelper.getAllSavings();
        else if(BUDGET == true) cursor = dbHelper.getAllBudget();

        if (cursor != null && cursor.getCount() > 0) {
            arrayList = new ArrayList<>();
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                double amount = cursor.getDouble(1);
                String reason = cursor.getString(2);
                long timeMillis = cursor.getLong(3);


                // Convert timestamp to human-readable format
                String formattedTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
                        .format(new Date(timeMillis));

                hashMap = new HashMap<>();
                hashMap.put("id", "" + id);
                hashMap.put("amount", "" + amount);
                hashMap.put("reason", "" + reason);
                hashMap.put("time", formattedTime);

                arrayList.add(hashMap);
            }
            double balance = 0;
            if(LOAN == true){
                balance = dbHelper.calculateTotalLoan();
                tvTotal_show.setText("Total Loan: ");
                int textColor = Color.parseColor("#F44336");
                tvBalance.setTextColor(textColor);
            }
            else if(OWE == true){
                balance = dbHelper.calculateTotalOwe();
                tvTotal_show.setText("Total Owe: ");
                int textColor = Color.parseColor("#800080");
                tvBalance.setTextColor(textColor);
            }
            else if(SAVINGS == true){
                balance = dbHelper.calculateTotalSavings();
                tvTotal_show.setText("Total Savings: ");
                int textColor = Color.parseColor("#2196F3");
                tvBalance.setTextColor(textColor);
            }
            else if(BUDGET == true){
                balance = dbHelper.calculateTotalBudget();
                tvTotal_show.setText("Total Budget: ");
                int textColor = Color.parseColor("#2196F3");
                tvBalance.setTextColor(textColor);
            }

            tvBalance.setText("৳ "+balance);

            // Set up the RecyclerView with the new adapter
            recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
            recyclerView.setAdapter(new MyAdapter());


            recyclerView.setVisibility(View.VISIBLE);
            noDataAnimation.setVisibility(View.GONE);
            tvNoDataMessage.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.GONE);
            noDataAnimation.setVisibility(View.VISIBLE);
            tvNoDataMessage.setVisibility(View.VISIBLE);
        }
    }

    public static class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            View view = null;
            if (EXPENSE == true)view = inflater.inflate(R.layout.item_expense, parent, false);  // Expense layout
            else if(INCOME == true) view = inflater.inflate(R.layout.item_income, parent, false);
            else if(LOAN == true) view = inflater.inflate(R.layout.item_loan, parent, false);
            else if(OWE == true) view = inflater.inflate(R.layout.item_owe, parent, false);
            else if(SAVINGS == true)view = inflater.inflate(R.layout.item_savings, parent, false);
            else if(BUDGET == true)view = inflater.inflate(R.layout.item_budget, parent, false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            hashMap = arrayList.get(position);

            String id = hashMap.get("id");
            String amount = hashMap.get("amount");
            String reason = hashMap.get("reason");
            String formattedTime = hashMap.get("time");

            holder.tvReason.setText(reason);
            holder.tvAmount.setText("৳ " + amount);
            holder.tvTime.setText(formattedTime);

            holder.btnDeleteItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (EXPENSE == true)dbHelper.deleteExpense(id);
                    else if(INCOME == true)dbHelper.deleteIncome(id);
                    else if(LOAN == true)dbHelper.deleteLoan(id);
                    else if(OWE == true) dbHelper.deleteOwe(id);
                    else if(SAVINGS == true)dbHelper.deleteSavings(id);
                    else if(BUDGET == true)dbHelper.deleteBudget(id);
                    loadData();
                }
            });

            holder.btnEditItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), AddData.class);

                    if (EXPENSE) intent.putExtra("TYPE", "EXPENSE");
                    else if (INCOME) intent.putExtra("TYPE", "INCOME");
                    else if (LOAN) intent.putExtra("TYPE", "LOAN");
                    else if (OWE) intent.putExtra("TYPE", "OWE");
                    else if (SAVINGS) intent.putExtra("TYPE", "SAVINGS");
                    else if (BUDGET) intent.putExtra("TYPE", "BUDGET");


                    intent.putExtra("EDIT_ID", id);
                    intent.putExtra("EDIT_AMOUNT", amount);
                    intent.putExtra("EDIT_REASON", reason);
                    v.getContext().startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public static class MyViewHolder extends RecyclerView.ViewHolder {
            TextView tvReason, tvAmount, tvTime;
            Button btnDeleteItem, btnEditItem;

            public MyViewHolder(View itemView) {
                super(itemView);
                tvReason = itemView.findViewById(R.id.tvReason);
                tvAmount = itemView.findViewById(R.id.tvAmount);
                tvTime = itemView.findViewById(R.id.tvTime);
                btnDeleteItem = itemView.findViewById(R.id.btnDeleteItem);
                btnEditItem = itemView.findViewById(R.id.btnEditItem);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
