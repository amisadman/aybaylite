package com.amisadman.aybay;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;

public class AddData extends AppCompatActivity {
    TextView tvTitle;
    EditText edAmount,edReason;
    Button button;

    DatabaseHelper dbHelper;
    LottieAnimationView animationAdd,animationUpdate;

    public static boolean EXPENSE = false;
    public static boolean INCOME = false;
    public static boolean LOAN = false;
    public static boolean OWE = false;
    public static boolean SAVINGS = false;
    public static boolean BUDGET = false;
    String editId = null;
    boolean isEdit = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_data);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.add_data_activity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        tvTitle = findViewById(R.id.tvTitle);
        edAmount = findViewById(R.id.edAmount);
        edReason = findViewById(R.id.edReason);
        button = findViewById(R.id.button);
        animationAdd = findViewById(R.id.animationAdd);
        animationUpdate = findViewById(R.id.animationUpdate);
        dbHelper = new DatabaseHelper(this);

        EXPENSE = INCOME = LOAN = OWE = SAVINGS= BUDGET = false;

        Intent intent = getIntent();
        String type = intent.getStringExtra("TYPE");

        if ("EXPENSE".equals(type)) {
            EXPENSE = true;
        } else if ("INCOME".equals(type)) {
            INCOME = true;
        }else if ("LOAN".equals(type)) {
            LOAN = true;
        } else if ("OWE".equals(type)) {
            OWE = true;
        } else if ("SAVINGS".equals(type)) {
            SAVINGS = true;
        } else if ("BUDGET".equals(type)) {
            BUDGET = true;
        }

        /*Edit Data
        Edit button theke ekhane ashe.
        */
        if (intent.hasExtra("EDIT_ID")) {
            isEdit = true;
            editId = intent.getStringExtra("EDIT_ID");
            edAmount.setText(intent.getStringExtra("EDIT_AMOUNT"));
            edReason.setText(intent.getStringExtra("EDIT_REASON"));
            if(EXPENSE == true) tvTitle.setText("Edit Expense");
            else if(INCOME == true) tvTitle.setText("Edit Income");
            else if(LOAN == true) tvTitle.setText("Edit Loan");
            else if(OWE == true) tvTitle.setText("Edit Owe");
            else if(SAVINGS == true)tvTitle.setText("Edit Savings");
            else if(BUDGET == true)tvTitle.setText("Edit Budget");
            animationUpdate.setVisibility(View.VISIBLE);
            animationAdd.setVisibility(View.GONE);
            button.setText("Update");
        } else {
            // Add Data
            if(EXPENSE == true) tvTitle.setText("Add Expense");
            else if(INCOME == true) tvTitle.setText("Add Income");
            else if(LOAN == true) tvTitle.setText("Add Loan");
            else if(OWE == true) tvTitle.setText("Add Owe");
            else if(SAVINGS == true)tvTitle.setText("Add Savings");
            else if(BUDGET == true)tvTitle.setText("Add Budget");
            animationUpdate.setVisibility(View.GONE);
            animationAdd.setVisibility(View.VISIBLE);

        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sAmount = edAmount.getText().toString();
                String reason = edReason.getText().toString();
                double amount = Double.parseDouble(sAmount);

                if (isEdit) {
                    //Update korbe
                    if (EXPENSE == true) {
                        dbHelper.updateExpense(editId, amount, reason);
                        ShowData.loadData();
                        finish();
                    }else if(INCOME == true) {
                        dbHelper.updateIncome(editId, amount, reason);
                        ShowData.loadData();
                        finish();
                    }
                    else if(LOAN == true) {
                        dbHelper.updateLoan(editId, amount, reason);
                        ShowData.loadData();
                        finish();
                    }
                    else if(OWE == true) {
                        dbHelper.updateOwe(editId, amount, reason);
                        ShowData.loadData();
                        finish();

                    }
                    else if(SAVINGS == true){
                        dbHelper.updateSavings(editId, amount, reason);
                        ShowData.loadData();
                        finish();

                    }
                    else if(BUDGET == true){
                        dbHelper.updateBudget(editId, amount, reason);
                        ShowData.loadData();
                        finish();

                    }

                    Toast.makeText(AddData.this, "Entry Updated!", Toast.LENGTH_SHORT).show();
                } else {
                    //Notun add
                    if (EXPENSE == true) {
                        dbHelper.addExpense(amount, reason);
                        Toast.makeText(AddData.this, "Expense Added!", Toast.LENGTH_SHORT).show();
                        finish();

                    }else if(INCOME == true) {
                        dbHelper.addIncome(amount, reason);
                        Toast.makeText(AddData.this, "Income Added!", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else if(LOAN == true) {
                        dbHelper.addLoan(amount, reason);
                        Toast.makeText(AddData.this, "Loan Added!", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else if(OWE == true) {
                        dbHelper.addOwe(amount, reason);
                        Toast.makeText(AddData.this, "Owe Added!", Toast.LENGTH_SHORT).show();
                        finish();

                    }
                    else if(SAVINGS == true){
                        dbHelper.addSavings(amount, reason);
                        Toast.makeText(AddData.this, "Savings Added!", Toast.LENGTH_SHORT).show();
                        finish();

                    }
                    else if(BUDGET == true){
                        dbHelper.addBudget(amount, reason);
                        Toast.makeText(AddData.this, "Budget Added!", Toast.LENGTH_SHORT).show();
                        finish();

                    }
                }

            }
        });
    }




    // back press
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}