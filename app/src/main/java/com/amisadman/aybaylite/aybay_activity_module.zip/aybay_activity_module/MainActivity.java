package com.amisadman.aybay;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity
{
    TextView tvFinalBalance, tvTotalExpense, tvTotalIncome, tvUsername,tvTotalSavings,tvTotalLoan,tvTotalOwe;
    LinearLayout btnAddExpense, btnAddIncome;
    LinearLayout btnShowAllDataIncome,btnLoan,btnOwe,btnSavings,btnManageLocal,btnManageCloud,btnBudget,btnShowAllDataExpense,btnSearch,btnWalleo;
    static RecyclerView recyclerView_main;
    static TextView tvNoDataMessage_main;
    static LottieAnimationView noDataAnimation_main;
    DatabaseHelper dbHelper = new DatabaseHelper(this);
    static ArrayList<HashMap<String, String>> arrayList = new ArrayList<>(); // Ensure it is always initialized

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_activity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvFinalBalance = findViewById(R.id.tvFinalBalance);
        tvTotalExpense = findViewById(R.id.tvTotalExpense);
        tvTotalIncome = findViewById(R.id.tvTotalIncome);
        tvTotalSavings = findViewById(R.id.tvTotalSavings);
        tvTotalLoan = findViewById(R.id.tvTotalLoan);
        tvTotalOwe = findViewById(R.id.tvTotalOwe);
        tvUsername = findViewById(R.id.tvUsername);
        btnAddExpense = findViewById(R.id.btnAddExpense);
        btnShowAllDataExpense = findViewById(R.id.btnShowAllDataExpense);
        btnAddIncome = findViewById(R.id.btnAddIncome);
        btnShowAllDataIncome = findViewById(R.id.btnShowAllDataIncome);
        btnLoan = findViewById(R.id.btnLoan);
        btnOwe = findViewById(R.id.btnOwe);
        btnSavings = findViewById(R.id.btnSavings);
        btnManageLocal = findViewById(R.id.btnManageLocal);
        btnManageCloud = findViewById(R.id.btnManageCloud);
        btnBudget = findViewById(R.id.btnBudget);
        btnSearch = findViewById(R.id.btnSearch);
        btnWalleo = findViewById(R.id.btnWalleo);
        recyclerView_main = findViewById(R.id.recyclerView_main);
        noDataAnimation_main = findViewById(R.id.noDataAnimation_main);
        tvNoDataMessage_main = findViewById(R.id.tvNoDataMessage_main);

        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        if(username != null)
        {
            tvUsername.setText(username + "!");
        }

        ImageButton btnLogout = findViewById(R.id.logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });

        btnAddExpense.setOnClickListener(v -> {

            Intent intent1 = new Intent(MainActivity.this, AddData.class);
            intent1.putExtra("TYPE", "EXPENSE");
            startActivity(intent1);
        });

        btnAddIncome.setOnClickListener(v -> {
            Intent intent1 = new Intent(MainActivity.this, AddData.class);
            intent1.putExtra("TYPE", "INCOME");
            startActivity(intent1);
        });

        btnShowAllDataExpense.setOnClickListener(v -> {
            Intent intent1 = new Intent(MainActivity.this, ShowData.class);
            intent1.putExtra("TYPE", "EXPENSE");
            startActivity(intent1);
        });

        btnShowAllDataIncome.setOnClickListener(v -> {
            Intent intent1 = new Intent(MainActivity.this, ShowData.class);
            intent1.putExtra("TYPE", "INCOME");
            startActivity(intent1);
        });
        btnLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, ShowData.class);
                intent1.putExtra("TYPE", "LOAN");
                startActivity(intent1);
            }
        });
        btnOwe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, ShowData.class);
                intent1.putExtra("TYPE", "OWE");
                startActivity(intent1);
            }
        });
        btnSavings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, ShowData.class);
                intent1.putExtra("TYPE", "SAVINGS");
                startActivity(intent1);
            }
        });
        btnBudget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, ShowData.class);
                intent1.putExtra("TYPE", "BUDGET");
                startActivity(intent1);
            }
        });
        btnManageLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, ManageLocalActivity.class);
                startActivity(intent1);
            }
        });
        btnManageCloud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, ManageCloudActivity.class);
                startActivity(intent1);
            }
        });
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(intent1);
            }
        });
        btnWalleo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, WalleoActivity.class);
                startActivity(intent1);
            }
        });

        loadDataFromDatabase();
        // Add border to each item
        int borderWidth = 2;  // 2px border width
        int borderColor = Color.parseColor("#D3D3D3");  // Light Gray border color
        recyclerView_main.addItemDecoration(new BorderItemDecoration(borderWidth, borderColor));
        setupRecyclerView();
        updateUI();
    }

    private void loadDataFromDatabase()
    {
        Cursor cursor = dbHelper.getStatement();
        arrayList.clear(); // Clear previous data

        if (cursor != null && cursor.getCount() > 0)
        {
            while(cursor.moveToNext())
            {
                String type = cursor.getString(0);
                double amount = cursor.getDouble(1);
                String reason = cursor.getString(2);
                long timeMillis = cursor.getLong(3);
                String formattedTime = new java.text.SimpleDateFormat("dd-MM-yyyy HH:mm:ss", java.util.Locale.getDefault())
                        .format(new java.util.Date(timeMillis));

                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("type", type);
                hashMap.put("amount", String.valueOf(amount));
                hashMap.put("reason", reason);
                hashMap.put("time", formattedTime);

                arrayList.add(hashMap);
            }
            cursor.close();
        }
    }

    private void setupRecyclerView()
    {

        recyclerView_main.setLayoutManager(new LinearLayoutManager(this));
        recyclerView_main.setAdapter(new MyAdapter());

        if(!arrayList.isEmpty())
        {
            recyclerView_main.setVisibility(View.VISIBLE);
            noDataAnimation_main.setVisibility(View.GONE);
            tvNoDataMessage_main.setVisibility(View.GONE);
        }
        else
        {
            recyclerView_main.setVisibility(View.GONE);
            noDataAnimation_main.setVisibility(View.VISIBLE);
            tvNoDataMessage_main.setVisibility(View.VISIBLE);
        }
    }

    public void updateUI()
    {
        tvTotalIncome.setText("৳ " + dbHelper.calculateTotalIncome());
        tvTotalExpense.setText("৳ " + dbHelper.calculateTotalExpense());
        double balance = Math.max(0, dbHelper.calculateTotalIncome() - dbHelper.calculateTotalExpense());
        tvFinalBalance.setText("৳ " + balance);
        tvTotalSavings.setText("৳ " + dbHelper.calculateTotalSavings());
        tvTotalLoan.setText("৳ " + dbHelper.calculateTotalLoan());
        tvTotalOwe.setText("৳ " + dbHelper.calculateTotalOwe());
    }
    public static class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

        public MyAdapter() {
        }

        public static class MyViewHolder extends RecyclerView.ViewHolder {
            TextView tvReason_main, tvAmount_main, tvTime_main;

            public MyViewHolder(View itemView)
            {
                super(itemView);
                tvReason_main = itemView.findViewById(R.id.tvReason_main);
                tvAmount_main = itemView.findViewById(R.id.tvAmount_main);
                tvTime_main = itemView.findViewById(R.id.tvTime_main);
            }
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_statement, parent, false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            HashMap<String, String> hashMap = arrayList.get(position);
            holder.tvReason_main.setText(hashMap.get("reason"));
            holder.tvTime_main.setText(hashMap.get("time"));

            String type = hashMap.get("type");
            String amount = hashMap.get("amount");
            if ("Income".equals(type)) {
                holder.tvAmount_main.setText("৳ +" + amount);
                int textColor = Color.parseColor("#228B22");
                holder.tvAmount_main.setTextColor(textColor);
            } else {
                holder.tvAmount_main.setText("৳ " + amount);
                holder.tvAmount_main.setTextColor(Color.RED);
            }
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        loadDataFromDatabase();
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDataFromDatabase();
        setupRecyclerView();
        updateUI();
    }
}
